// Funcionalidad extra pedida en la consigna: cambiar entre tema oscuro y claro.
const botonTema = document.getElementById("tema");

botonTema.addEventListener("click", function () {
    document.body.classList.toggle("claro");
});

// Validación sencilla del formulario antes de enviarlo a Formspree.
const formulario = document.getElementById("form-contacto");

formulario.addEventListener("submit", function (evento) {
    const email = document.getElementById("email").value.trim();
    const mensaje = document.getElementById("mensaje").value.trim();
    const error = document.getElementById("error-form");

    error.textContent = "";

    if (!email.includes("@") || !email.includes(".")) {
        evento.preventDefault();
        error.textContent = "Ingresá un email válido.";
    } else if (mensaje.length < 10) {
        evento.preventDefault();
        error.textContent = "El mensaje debe tener al menos 10 caracteres.";
    }
});
