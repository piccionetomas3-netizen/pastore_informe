MI REPRODUCTOR DE MÚSICA
========================

Contenido:
- reproductor.py: código fuente del programa.
- requirements.txt: librería necesaria para reproducir audio.

REQUISITOS
- Python 3 instalado.
- Windows, Linux o macOS con interfaz gráfica.
- Conexión a Internet solo para instalar pygame.

CÓMO EJECUTAR
1. Abrí una terminal o consola en esta carpeta.
2. Ejecutá:
   python -m pip install -r requirements.txt
3. Después ejecutá:
   python reproductor.py

CÓMO USAR
1. Tocá "Agregar canciones".
2. Elegí archivos MP3, WAV u OGG.
3. Hacé doble clic en una canción o usá los controles.
4. Ajustá el volumen con la barra.

CÓMO CREAR UN .EXE EN WINDOWS
1. Instalá pygame:
   python -m pip install pygame pyinstaller
2. En la terminal, dentro de esta carpeta, ejecutá:
   pyinstaller --onefile --windowed --name MiReproductor reproductor.py
3. El ejecutable se creará en la carpeta dist.

IMPORTANTE
El programa no incluye canciones. Cada persona selecciona los archivos de audio
que tiene guardados en su computadora. Para que otra persona lo ejecute como
programa .py, también deberá tener Python y pygame instalados. Si entregás el
archivo .exe, no necesita instalar Python, aunque conviene probarlo antes de
entregarlo en la computadora donde se va a usar.
