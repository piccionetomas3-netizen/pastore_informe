import tkinter as tk
from tkinter import filedialog, messagebox
import os
import pygame

class ReproductorMusica:
    def __init__(self, ventana):
        self.ventana = ventana
        self.ventana.title("Mi reproductor de música")
        self.ventana.geometry("560x470")
        self.ventana.minsize(480, 420)
        self.ventana.configure(bg="#18212f")

        pygame.mixer.init()
        self.canciones = []
        self.indice_actual = -1
        self.pausado = False

        titulo = tk.Label(
            ventana, text="MI REPRODUCTOR DE MÚSICA",
            font=("Arial", 17, "bold"), bg="#18212f", fg="white"
        )
        titulo.pack(pady=(18, 12))

        self.nombre_cancion = tk.Label(
            ventana, text="Elegí una canción para comenzar",
            font=("Arial", 10), bg="#18212f", fg="#cbd5e1",
            wraplength=500
        )
        self.nombre_cancion.pack(pady=(0, 10))

        marco_lista = tk.Frame(ventana, bg="#18212f")
        marco_lista.pack(fill="both", expand=True, padx=22, pady=4)

        self.lista = tk.Listbox(
            marco_lista, bg="#253247", fg="white",
            selectbackground="#3977d5", selectforeground="white",
            font=("Arial", 10), borderwidth=0, highlightthickness=0
        )
        barra = tk.Scrollbar(marco_lista, command=self.lista.yview)
        self.lista.configure(yscrollcommand=barra.set)
        self.lista.pack(side="left", fill="both", expand=True)
        barra.pack(side="right", fill="y")
        self.lista.bind("<Double-Button-1>", self.reproducir_seleccion)

        tk.Button(
            ventana, text="＋ Agregar canciones", command=self.agregar_canciones,
            bg="#3977d5", fg="white", activebackground="#2b63b8",
            activeforeground="white", relief="flat", padx=12, pady=7
        ).pack(pady=10)

        controles = tk.Frame(ventana, bg="#18212f")
        controles.pack(pady=4)

        opciones = [
            ("⏮ Anterior", self.anterior),
            ("▶ Reproducir", self.reproducir_seleccion),
            ("⏸ Pausar / Seguir", self.pausar),
            ("⏹ Detener", self.detener),
            ("Siguiente ⏭", self.siguiente),
        ]
        for texto, funcion in opciones:
            tk.Button(
                controles, text=texto, command=funcion,
                bg="#334155", fg="white", activebackground="#475569",
                activeforeground="white", relief="flat", padx=7, pady=7
            ).pack(side="left", padx=3)

        volumen_marco = tk.Frame(ventana, bg="#18212f")
        volumen_marco.pack(pady=(12, 15))
        tk.Label(
            volumen_marco, text="Volumen", bg="#18212f", fg="white"
        ).pack(side="left", padx=(0, 8))
        self.volumen = tk.Scale(
            volumen_marco, from_=0, to=100, orient="horizontal",
            command=self.cambiar_volumen, bg="#18212f", fg="white",
            troughcolor="#3977d5", highlightthickness=0, length=210
        )
        self.volumen.set(70)
        self.volumen.pack(side="left")

        self.estado = tk.Label(
            ventana, text="Listo", bg="#18212f", fg="#94a3b8", font=("Arial", 9)
        )
        self.estado.pack(pady=(0, 8))

        ventana.protocol("WM_DELETE_WINDOW", self.cerrar)

    def agregar_canciones(self):
        archivos = filedialog.askopenfilenames(
            title="Seleccionar canciones",
            filetypes=[
                ("Archivos de audio", "*.mp3 *.wav *.ogg"),
                ("Todos los archivos", "*.*")
            ]
        )
        for archivo in archivos:
            if archivo not in self.canciones:
                self.canciones.append(archivo)
                self.lista.insert(tk.END, os.path.basename(archivo))
        if archivos:
            self.estado.config(text=f"{len(self.canciones)} canción(es) en la lista")

    def reproducir_seleccion(self, evento=None):
        seleccion = self.lista.curselection()
        if seleccion:
            self.reproducir(seleccion[0])
        elif self.indice_actual >= 0:
            self.reproducir(self.indice_actual)
        elif self.canciones:
            self.reproducir(0)
        else:
            messagebox.showinfo("Sin canciones", "Primero agregá una o más canciones.")

    def reproducir(self, indice):
        if not self.canciones or indice < 0 or indice >= len(self.canciones):
            return
        try:
            pygame.mixer.music.load(self.canciones[indice])
            pygame.mixer.music.set_volume(self.volumen.get() / 100)
            pygame.mixer.music.play()
            self.indice_actual = indice
            self.pausado = False
            nombre = os.path.basename(self.canciones[indice])
            self.nombre_cancion.config(text=f"Reproduciendo: {nombre}")
            self.lista.selection_clear(0, tk.END)
            self.lista.selection_set(indice)
            self.lista.activate(indice)
            self.estado.config(text="Reproduciendo")
        except pygame.error as error:
            messagebox.showerror(
                "No se pudo reproducir",
                f"No se pudo abrir este archivo de audio:\\n{self.canciones[indice]}\\n\\nDetalle: {error}"
            )

    def pausar(self):
        if self.indice_actual < 0:
            self.estado.config(text="Elegí una canción primero")
            return
        if self.pausado:
            pygame.mixer.music.unpause()
            self.pausado = False
            self.estado.config(text="Reproduciendo")
        else:
            pygame.mixer.music.pause()
            self.pausado = True
            self.estado.config(text="En pausa")

    def detener(self):
        pygame.mixer.music.stop()
        self.pausado = False
        self.estado.config(text="Detenido")

    def anterior(self):
        if self.canciones:
            destino = self.indice_actual - 1 if self.indice_actual > 0 else len(self.canciones) - 1
            self.reproducir(destino)

    def siguiente(self):
        if self.canciones:
            destino = (self.indice_actual + 1) % len(self.canciones)
            self.reproducir(destino)

    def cambiar_volumen(self, valor):
        pygame.mixer.music.set_volume(float(valor) / 100)

    def cerrar(self):
        pygame.mixer.music.stop()
        pygame.mixer.quit()
        self.ventana.destroy()

if __name__ == "__main__":
    ventana = tk.Tk()
    try:
        app = ReproductorMusica(ventana)
        ventana.mainloop()
    except pygame.error as error:
        messagebox.showerror(
            "Error de audio",
            f"No se pudo iniciar el sistema de audio.\\n{error}"
        )
        ventana.destroy()
